# cat_dog_detect > 2023-10-23 9:19am
https://universe.roboflow.com/gjschool/cat_dog_detect-nsgpd

Provided by a Roboflow user
License: CC BY 4.0

