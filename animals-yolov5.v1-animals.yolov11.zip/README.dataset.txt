# animals-yolov5 > animals
https://universe.roboflow.com/yolo-2xmbu/animals-yolov5-gslnk

Provided by a Roboflow user
License: Public Domain

